package com.anas.clipboard

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Clipboard contents are encrypted at rest with an Android Keystore AES-GCM key.
 * The app deliberately reads clipboard only while visible (Android platform restriction).
 */
class MainActivity : Activity() {
    private lateinit var clipboard: ClipboardManager
    private lateinit var list: LinearLayout
    private lateinit var empty: TextView
    private val prefs by lazy { getSharedPreferences("anas_clips", Context.MODE_PRIVATE) }
    private val clips = mutableListOf<ClipEntry>()
    private var listenerRegistered = false
    private var unlocked = false
    private var lockDialog: AlertDialog? = null

    private data class ClipEntry(val text: String, val createdAt: Long)

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        if (unlocked && hasPin()) readCurrentClipboard()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Hide clipboard contents from screenshots and the recent-apps preview.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        buildScreen()
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (!unlocked) showUnlockOrSetup()
    }

    override fun onPause() {
        unregisterClipboardListener()
        unlocked = false
        super.onPause()
    }

    private fun hasPin() = prefs.contains("pin_hash") && prefs.contains("pin_salt")

    private fun showUnlockOrSetup() {
        if (isFinishing || lockDialog?.isShowing == true) return
        val firstRun = !hasPin()
        val field = EditText(this).apply {
            inputType = 2
            hint = if (firstRun) "أنشئ رمزاً من 6 أرقام على الأقل" else "أدخل رمز القفل"
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
            addView(field, LinearLayout.LayoutParams(-1, dp(54)))
        }
        lockDialog = AlertDialog.Builder(this)
            .setTitle(if (firstRun) "إنشاء قفل لتطبيق أنس" else "التطبيق مقفل")
            .setMessage(if (firstRun) "اختر رمزاً لا يعرفه غيرك. لا يمكن استعادة النصوص المشفرة إذا نسيت الرمز بعد حذف التطبيق أو بياناته." else "أدخل رمزك لفتح النصوص المحفوظة.")
            .setView(container)
            .setCancelable(false)
            .setPositiveButton(if (firstRun) "حفظ الرمز" else "فتح", null)
            .create()
        lockDialog?.setOnShowListener {
            lockDialog?.getButton(AlertDialog.BUTTON_POSITIVE)?.setOnClickListener {
                val pin = field.text.toString()
                if (firstRun) {
                    if (pin.length < 6 || !pin.all { it.isDigit() }) {
                        field.error = "استخدم 6 أرقام على الأقل"; return@setOnClickListener
                    }
                    savePin(pin)
                    unlock()
                    lockDialog?.dismiss()
                } else if (verifyPin(pin)) {
                    unlock()
                    lockDialog?.dismiss()
                } else field.error = "الرمز غير صحيح"
            }
        }
        lockDialog?.show()
    }

    private fun savePin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derivePinHash(pin, salt)
        prefs.edit().putString("pin_salt", b64(salt)).putString("pin_hash", b64(hash)).apply()
    }

    private fun verifyPin(pin: String): Boolean = try {
        val salt = Base64.decode(prefs.getString("pin_salt", ""), Base64.NO_WRAP)
        val expected = Base64.decode(prefs.getString("pin_hash", ""), Base64.NO_WRAP)
        val actual = derivePinHash(pin, salt)
        actual.contentEquals(expected)
    } catch (_: Exception) { false }

    private fun derivePinHash(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 150_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }

    private fun unlock() {
        unlocked = true
        try {
            loadClips()
            registerClipboardListener()
            readCurrentClipboard()
            renderClips()
        } catch (e: Exception) {
            unlocked = false
            unregisterClipboardListener()
            Toast.makeText(this, "تعذر فتح التخزين المشفر. لا تحذف بيانات التطبيق قبل التواصل مع الدعم.", Toast.LENGTH_LONG).show()
        }
    }

    private fun registerClipboardListener() {
        if (!listenerRegistered) {
            clipboard.addPrimaryClipChangedListener(clipListener)
            listenerRegistered = true
        }
    }

    private fun unregisterClipboardListener() {
        if (listenerRegistered) {
            clipboard.removePrimaryClipChangedListener(clipListener)
            listenerRegistered = false
        }
    }

    private fun encryptionKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val alias = "anas_clipboard_aes_key"
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    private fun encrypt(plain: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, encryptionKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        val packed = ByteBuffer.allocate(4 + iv.size + encrypted.size).putInt(iv.size).put(iv).put(encrypted).array()
        return b64(packed)
    }

    private fun decrypt(encoded: String): String {
        val packed = ByteBuffer.wrap(Base64.decode(encoded, Base64.NO_WRAP))
        val ivSize = packed.int
        require(ivSize in 12..16 && ivSize <= packed.remaining())
        val iv = ByteArray(ivSize).also { packed.get(it) }
        val encrypted = ByteArray(packed.remaining()).also { packed.get(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, encryptionKey(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }

    private fun b64(bytes: ByteArray) = Base64.encodeToString(bytes, Base64.NO_WRAP)

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val incoming = when (intent.action) {
            Intent.ACTION_SEND -> intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
            Intent.ACTION_PROCESS_TEXT -> intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            else -> null
        }
        if (!incoming.isNullOrBlank()) {
            // The shared text is held only in memory until the user unlocks the app.
            pendingSharedText = incoming
        }
    }

    private var pendingSharedText: String? = null

    private fun readCurrentClipboard() {
        if (!unlocked) return
        try {
            if (clipboard.hasPrimaryClip()) {
                val text = clipboard.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
                if (!text.isNullOrBlank()) addClip(text)
            }
        } catch (_: SecurityException) {
            // Expected when Android restricts clipboard access.
        } catch (_: Exception) { }
    }

    private fun loadClips() {
        clips.clear()
        val raw = prefs.getString("items_encrypted", null)
        if (raw != null) {
            val arr = JSONArray(decrypt(raw))
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                clips.add(ClipEntry(obj.getString("text"), obj.getLong("time")))
            }
        } else {
            // One-time migration from v1's plaintext SharedPreferences into encrypted storage.
            val legacy = prefs.getString("items", null)
            if (!legacy.isNullOrBlank()) {
                val oldItems = JSONArray(legacy)
                val now = System.currentTimeMillis()
                for (i in 0 until oldItems.length()) {
                    val value = oldItems.optString(i, "")
                    if (value.isNotBlank()) clips.add(ClipEntry(value, now))
                }
                persist()
                prefs.edit().remove("items").apply()
            }
        }
        applyRetention()
        pendingSharedText?.let { addClip(it); pendingSharedText = null }
    }

    private fun persist() {
        val arr = JSONArray()
        clips.forEach { entry -> arr.put(JSONObject().put("text", entry.text).put("time", entry.createdAt)) }
        prefs.edit().putString("items_encrypted", encrypt(arr.toString())).apply()
    }

    private fun retentionMillis(): Long = when (prefs.getInt("retention_days", 30)) {
        1 -> 24L * 60 * 60 * 1000
        7 -> 7L * 24 * 60 * 60 * 1000
        30 -> 30L * 24 * 60 * 60 * 1000
        else -> Long.MAX_VALUE
    }

    private fun applyRetention() {
        val age = retentionMillis()
        if (age == Long.MAX_VALUE) return
        val cutoff = System.currentTimeMillis() - age
        if (clips.removeAll { it.createdAt < cutoff }) persist()
    }

    private fun addClip(text: String) {
        val clean = text.trim()
        if (!unlocked || clean.isEmpty() || clips.firstOrNull()?.text == clean) return
        clips.removeAll { it.text == clean }
        clips.add(0, ClipEntry(clean, System.currentTimeMillis()))
        while (clips.size > 500) clips.removeAt(clips.lastIndex)
        applyRetention()
        persist()
        if (::list.isInitialized) renderClips()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(16))
            setBackgroundColor(0xFFF4F7FB.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = TextView(this).apply {
            text = "تطبيق أنس"; textSize = 27f; setTextColor(0xFF102A43.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }
        root.addView(header, LinearLayout.LayoutParams(-1, dp(48)))
        val subtitle = TextView(this).apply {
            text = "حافظتك المشفرة للنصوص المنسوخة"; textSize = 14f
            setTextColor(0xFF52606D.toInt()); gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(30)))
        val info = TextView(this).apply {
            text = "الحفظ مشفّر على جهازك. أندرويد لا يسمح بقراءة الحافظة باستمرار في الخلفية؛ ارجع للتطبيق بعد النسخ أو استخدم مشاركة النص إلى تطبيق أنس."
            textSize = 13f; setTextColor(0xFF334E68.toInt()); setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFE1ECF4.toInt())
        }
        val infoParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(12), 0, dp(12)) }
        root.addView(info, infoParams)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val saveButton = Button(this).apply {
            text = "حفظ من الحافظة الآن"
            setOnClickListener { readCurrentClipboard(); Toast.makeText(this@MainActivity, "تم تحديث الحافظة", Toast.LENGTH_SHORT).show() }
        }
        actions.addView(saveButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        val settingsButton = Button(this).apply { text = "الحماية"; setOnClickListener { showSecuritySettings() } }
        actions.addView(settingsButton, LinearLayout.LayoutParams(-2, dp(48)))
        val clearButton = Button(this).apply {
            text = "مسح الكل"
            setOnClickListener { AlertDialog.Builder(this@MainActivity).setMessage("حذف كل النصوص المحفوظة؟")
                .setNegativeButton("إلغاء", null).setPositiveButton("حذف") { _, _ -> clips.clear(); persist(); renderClips() }.show() }
        }
        actions.addView(clearButton, LinearLayout.LayoutParams(-2, dp(48)))
        root.addView(actions)
        empty = TextView(this).apply {
            text = "ما في نصوص محفوظة لسه."; textSize = 16f; setTextColor(0xFF627D98.toInt())
            gravity = Gravity.CENTER; setPadding(0, dp(28), 0, dp(28))
        }
        root.addView(empty, LinearLayout.LayoutParams(-1, -2))
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showSecuritySettings() {
        val options = arrayOf("تغيير رمز القفل", "مدة الاحتفاظ بالنصوص", "قفل التطبيق الآن")
        AlertDialog.Builder(this).setTitle("الحماية والخصوصية").setItems(options) { _, which ->
            when (which) {
                0 -> changePin()
                1 -> chooseRetention()
                2 -> { unregisterClipboardListener(); unlocked = false; showUnlockOrSetup() }
            }
        }.show()
    }

    private fun changePin() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), 0, dp(22), 0) }
        val oldPin = EditText(this).apply { hint = "الرمز الحالي"; inputType = 2 }
        val newPin = EditText(this).apply { hint = "الرمز الجديد (6 أرقام على الأقل)"; inputType = 2 }
        box.addView(oldPin); box.addView(newPin)
        AlertDialog.Builder(this).setTitle("تغيير رمز القفل").setView(box)
            .setNegativeButton("إلغاء", null).setPositiveButton("حفظ", null).create().also { dialog ->
                dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val old = oldPin.text.toString(); val fresh = newPin.text.toString()
                    if (!verifyPin(old)) oldPin.error = "الرمز الحالي غير صحيح"
                    else if (fresh.length < 6 || !fresh.all { it.isDigit() }) newPin.error = "استخدم 6 أرقام على الأقل"
                    else { savePin(fresh); dialog.dismiss(); Toast.makeText(this, "تم تغيير الرمز", Toast.LENGTH_SHORT).show() }
                } }
                dialog.show()
            }
    }

    private fun chooseRetention() {
        val labels = arrayOf("يوم واحد", "7 أيام", "30 يوماً", "بدون حذف تلقائي")
        val values = intArrayOf(1, 7, 30, 0)
        val current = prefs.getInt("retention_days", 30)
        val selected = values.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("حذف النصوص تلقائياً بعد")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                prefs.edit().putInt("retention_days", values[which]).apply()
                applyRetention(); persist(); renderClips(); dialog.dismiss()
                Toast.makeText(this, "تم تحديث مدة الاحتفاظ", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun renderClips() {
        if (!::list.isInitialized || !unlocked) return
        list.removeAllViews()
        empty.visibility = if (clips.isEmpty()) View.VISIBLE else View.GONE
        clips.forEachIndexed { index, entry ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(8))
                setBackgroundColor(0xFFFFFFFF.toInt()); layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            val body = TextView(this).apply {
                text = entry.text; textSize = 15f; setTextColor(0xFF243B53.toInt())
                maxLines = 8; setTextIsSelectable(true)
            }
            card.addView(body)
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val copy = Button(this).apply {
                text = "نسخ"; setOnClickListener {
                    clipboard.setPrimaryClip(ClipData.newPlainText("نص محفوظ", entry.text))
                    Toast.makeText(this@MainActivity, "تم النسخ", Toast.LENGTH_SHORT).show()
                }
            }
            buttons.addView(copy)
            val delete = Button(this).apply {
                text = "حذف"; setOnClickListener { clips.remove(entry); persist(); renderClips() }
            }
            buttons.addView(delete); card.addView(buttons)
            val params = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(10)) }
            list.addView(card, params)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
